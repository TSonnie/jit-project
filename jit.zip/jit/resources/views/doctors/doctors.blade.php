@extends('adminlte::page')

@section('Doctors', 'Dashboard')

@section('content_header')
    <h1>Doctors</h1>
@stop

@section('css')
    {{--    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">--}}
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
@stop

@section('content')
    <a class="btn btn-primary" type="button" href="{{route('doctor_create')}}">Add Doctor</a>
<table id="doctors" class="table table-striped table-bordered table-hover" style="width:100%">
    <thead>
    <tr>

        <th >First Name</th>
        <th>Last Name</th>
        <th>Email</th>

    </tr>
    </thead>
    <tbody>
    @foreach($doctors as $doc)
        <tr>
            <td>{{$doc->fname}}</td>
            <td>{{$doc->lname}}</td>
            <td>{{$doc->email}}</td>

        </tr>
    @endforeach
    </tbody>

</table>




@stop



@section('js')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#doctors').DataTable();
        } );
    </script>


    <script src="{{asset('js/jquery.min.js')}}"></script>
    <script src=" https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src=" https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src=" https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
@stop
