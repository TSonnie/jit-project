@extends('adminlte::page')

@section('Doctors', 'Dashboard')

@section('content_header')
    <h1>New Doctor</h1>
@stop

@section('css')

@stop

@section('content')

    <form id="post_form" method="POST" action="{{ route('add_doctor') }}" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group">
            <label for="fname">First Name</label>
            <input type="text" name="fname" value="{{old('fname')}}" class="form-control" id="fname" placeholder="First Name...">

        </div>
        <div class="form-group">
            <label for="lname">Last Name</label>
            <input type="text" name="lname" value="{{old('lname')}}" class="form-control" id="lname" placeholder="Last Name...">

        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" name="email" value="{{old('email')}}" class="form-control" id="email" placeholder="Email...">

        </div>

        <div class="form-group col-md-4">
            {{--<label for="countryid">Country:</label>--}}
            @if($dept->count()>0)
                <select class="form-control" name="dept_id" id="dept_id">
                    <option value="" >Select a Department</option>
                    @foreach($dept as $department)
                        <option value="{{ $department->id }}">{{ $department->department_name }}</option>
                    @endforeach
                    @else
                        No Department found
                    @endif
                </select>
        </div>



        <button type="submit" id="post_form" class="btn btn-primary pull-right">Save</button>
    </form>

@stop



@section('js')

@stop
