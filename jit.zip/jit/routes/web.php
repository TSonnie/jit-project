<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/doctors', 'DoctorsController@getAllDoctors')->name('get_doctors');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/doctor/show', 'DoctorsController@show')->name("doctor_create");
Route::post('/add_doctor', 'DoctorsController@createDoc')->name("add_doctor");

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('report','DynamicReportPDF@index');

Route::get('report/pdf','DynamicReportPDF@pdf');

