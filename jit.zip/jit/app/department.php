<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class department extends Model
{
    //
    protected $table='department';
    protected $fillable=['department_name','wing','desc'];

    public function docs()
    {
        return $this->belongsTo('App\doctors');
    }
}
