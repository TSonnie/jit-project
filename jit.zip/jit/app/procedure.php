<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class procedure extends Model
{
    //
    public $table=' procedure';
    protected $fillable=['procedure_name','cost'];
}
