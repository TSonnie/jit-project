<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use PDF;

class DynamicReportPDF extends report
{

    function index()
    {
        $doctors_data = this->get_doctors_data();
            return view('report')->with('doctors_data',$doctors_data);
    }
    function get_doctors_data()
    {
        $doctors_data = DB::table('tbl_doctors')
                      ->limit (20)
                      ->get()
            return $doctors_data;
    }
    function pdf()
    {
        $pdf = \App::make('dompf.wrapper');
        $pdf ->loadHTML($this->convert_doctors_data_to_html());
    }
    function convert_doctors_data_to_html()
    {
        $doctors_data=$this->get_doctors_data();
        $output='
        <h3 align="center">Doctors Data</h3>
        <table width="100%" style="border-collapse:collapse; border:0px;">
           <tr>
               <th>style="border: 1px solid padding:12px;" width:"15%">ID</th> 
               <th>style="border: 1px solid padding:12px;" width:"20%">Name</th> 
               <th>style="border: 1px solid padding:12px;" width:"30%">Email</th> 
               <th>style="border: 1px solid padding:12px;" width:"30%">Department</th> 
           </tr> ';
           @foreach ($doctors_data as $doctors) {
               $output .= '
                  <tr>
                      <td style="border: 1px solid; padding: 12px;>'.$doctor->id.'</td>
                      <td style="border: 1px solid; padding: 12px;>'.$doctor->Name.'</td>
                      <td style="border: 1px solid; padding: 12px;>'.$doctor->Email.'</td>
                      <td style="border: 1px solid; padding: 12px;>'.$doctor->Department.'</td>
                  </tr>
                  ';
                }
                $output .= '</table>';
    }
?>

