<?php

namespace App\Http\Controllers;

use App\department;
use App\doctors;
use App\patient;
use Illuminate\Http\Request;

class DoctorsController extends Controller
{
    //get all doctors

    public function getAllDoctors()
    {
        $doctors = doctors::with('departments')
            ->get();

        return view('doctors.doctors',['doctors'=>$doctors]);
    }

//    get a single doctor

    public function getSingleDoc(Request $request)
    {
        $doc_id = $request->id;
        $doctors =doctors::with('departments')
            ->where('id',$doc_id)
            ->get();

        return view('',["doc"=>$doctors]);

    }
    // show to creat form for creating the doc
    public function show(){
        $dept=department::all();
        return view('doctors.create_doc',['dept'=>$dept]);
    }

//    save doc
    public function createDoc(Request $request)
    {
        try{

          $doc=doctors::create(array(
              'fname'=>$request->fname,
            'lname'=>$request->lname,
            'email'=>$request->email,
            'dept_id'=>$request->dept_id
          ));

          if ($doc){
              return redirect(route("get_doctors"))->with("success", 'Successifully Added '.$doc->fname.' into Doctors');
          }else{
              return redirect()->back()
                  ->withErrors([
                      'errors' => 'unable to create category',
                  ]);
          }
        }catch (\Exception $exception){
            return redirect()->back()
                ->withErrors([
                    'errors' => $exception->getMessage(),
                ]);
        }

    }
}
