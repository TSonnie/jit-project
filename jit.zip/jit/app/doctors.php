<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doctors extends Model
{
    //
    protected $table='doctors';
    protected $fillable = [];

    public function departments()
    {
        return $this ->hasMany('App\department','dept_id','id');
    }

    public function patient()
    {
        return $this->hasMany('App\patient','patient_id','id');
    }
}
