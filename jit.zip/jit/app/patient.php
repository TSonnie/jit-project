<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class patient extends Model
{
    //
    protected  $table ='patient';
    protected $fillable=[];
public function  medication ()
{
 return $this-> hasMany('app\medication','medication_id','id' );
}
}
