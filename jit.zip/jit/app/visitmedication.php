<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class visitmedication extends Model
{
    //
    protected $table='visitmedication';
    protected $fillable=[];

    public function visits()
    {
        return $this->hasMany('app\visits', 'visit_id', 'id');
    }
    public function medication()
    {
        return $this->hasMany('app\medication', 'medication_id', 'id');
    }
}
