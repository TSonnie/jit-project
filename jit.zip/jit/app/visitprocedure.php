<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class visitprocedure extends Model
{
    //
    protected $table='visitprocedure';
    protected $fillable=[];
    public function visits()
{
    return $this->hasMany('app\visits', 'visit_id', 'id');
}
    public function procedure ()
    {
        return $this->hasMany('app\procedure', 'procedure_id', 'id');
    }

}
