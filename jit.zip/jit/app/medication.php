<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class medication extends Model
{
    //
    protected $table='';
    protected $fillable=[ 'medication_name','cost'];


   // public function  med ()
  //  {
      //  return $this->belongsTo(app)
   // }
}
