<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class visits extends Model
{
    //
    protected $table='visits';
    protected $fillable=[];
    public function doctors()
    {
        return $this->hasMany('app\doctors', 'doctor_id', 'id');
    }
    public function patient()
    {
        return $this->hasMany('app\patient', 'patient_id', 'id');
    }
}
