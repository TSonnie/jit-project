<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class schedule extends Model
{
    //
    protected $table='schedule';
    protected $fillable=[];

    public function patient()
    {
        return $this->hasMany('app\patient', 'patient_id', 'id');
    }

    public function doctors()
    {
        return $this->hasMany('app\doctors', 'doctor_id', 'id');
    }
    public function shift()
    {
        return $this->hasMany('app\shift', 'shift_id', 'id');
    }
}
