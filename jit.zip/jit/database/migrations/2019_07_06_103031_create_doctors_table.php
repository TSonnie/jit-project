<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDoctorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('doctors', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('email')->unique();
            $table->unsignedBigInteger('patient_id');
            $table->string("password");
            $table->string('fname');
            $table->string('lname');
            $table->unsignedBigInteger('dept_id');
            $table->timestamps();

            $table->foreign('dept_id')
                ->references('id')->on('department')
                ->onUpdate('cascade')
                ->onDelete('restrict');

            $table->foreign('patient_id')
                ->references('id')->on('patient')
                ->onUpdate('cascade')
                ->onDelete('restrict');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('doctors');
    }
}
