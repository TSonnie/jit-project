<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->integer('admission_status')->default(0);
            $table->unsignedBigInteger('medication_id');
            $table->dateTime('discharge_date')->nullable();
            $table->dateTime('admission_date')->nullable();
            $table->string('gender');
            $table->dateTime('dob');
            $table->timestamps();

            $table->foreign('medication_id')
                ->references('id')->on('medication')
                ->onUpdate('cascade')
                ->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient');
    }
}
