<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateScheduleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('schedule', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->dateTime('time_in');
            $table->dateTime('time_out');
            $table->unsignedBigInteger('patient_id');
            $table->unsignedBigInteger('doctor_id');
            $table->unsignedBigInteger('shift_id');
            $table->text('address');
            $table->string('phoneNumber');
            $table->timestamps();

            $table->foreign('patient_id')
                ->references('id')->on('patient')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('doctor_id')
                ->references('id')->on('doctors')
                ->onUpdate('cascade')
                ->onDelete('restrict');

            $table->foreign('shift_id')
                ->references('id')->on('shift')
                ->onUpdate('cascade')
                ->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('schedule');
    }
}
