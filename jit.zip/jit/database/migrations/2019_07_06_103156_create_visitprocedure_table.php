<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVisitprocedureTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('visitprocedure', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('visit_id');
            $table->unsignedBigInteger('procedure_id');
            $table->string('quantity')->nullable();
            $table->string('cost')->nullable();
            $table->timestamps();

            $table->foreign('visit_id')
                ->references('id')->on('visits')
                ->onUpdate('cascade')
                ->onDelete('restrict');

            $table->foreign('procedure_id')
                ->references('id')->on('procedure')
                ->onUpdate('cascade')
                ->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('visitprocedure');
    }
}
